window.onload = function () {
  const canvas = document.getElementById('canvas')
  const ctx = canvas.getContext('2d')
  const canvas2 = document.getElementById('canvas2')
  const ctx2 = canvas2.getContext('2d')

  canvas.height = window.innerHeight;
  canvas.width = window.innerWidth;
  canvas2.height = window.innerHeight;
  canvas2.width = window.innerWidth;

  const fps = 120;
  const dropsDeg = - Math.PI * 10 / 18

  var rainDrawInterval, drops = [], dropsCount = 220,
      lastFlashTime = 0;
  class Drops {
    x;
    y;
    length;
    deg;
    opacity;
  }

  for (let i = 0; i < dropsCount; i ++) {
    drops[i] = new Drops();
    drops[i].x = Math.random() * window.innerWidth;
    drops[i].y = Math.random() * window.innerHeight;
    drops[i].length = 50 + 100 * Math.random();
    drops[i].deg = - Math.PI / 18 * (9.5 + Math.random());
    drops[i].opacity = 0.2 + 0.6 * Math.random();
  }

  function makeFlash (startTime, endTime) {
    let startSteps = Math.round(startTime * fps / 1000),
        endSteps = Math.round(endTime * fps / 1000);

    for (let i = 0; i < startSteps; i ++) {
      setTimeout(function () {
        ctx2.beginPath();
        ctx2.clearRect(0, 0, window.innerWidth, window.innerHeight);
        ctx2.fillStyle = `rgba(255, 255, 255, ${1 / startSteps * i})`;
        ctx2.fillRect(0, 0, window.innerWidth, window.innerHeight);
      }, startTime / startSteps * (i + 1));
    }

    for (let i = 0; i < endSteps; i ++) {
      setTimeout(function () {
        ctx2.beginPath();
        ctx2.clearRect(0, 0, window.innerWidth, window.innerHeight);
        ctx2.fillStyle = `rgba(255, 255, 255, ${1 - (1 / endSteps * i)})`;
        ctx2.fillRect(0, 0, window.innerWidth, window.innerHeight);
      }, endTime / endSteps * (i + 1));
    }
    // ctx.fillRect(0, 0, window.innerWidth, window.innerHeight)
  }

  function drawDrops (fullDropTime) {
    rainDrawInterval = setInterval(function () {
      let s = Math.abs((drops[0].length * 2 + window.innerHeight) / Math.sin(dropsDeg)),
          v = s / fullDropTime;
      ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
      for(let i = 0; i < dropsCount; i ++ ) {
        ctx.beginPath();
        ctx.strokeStyle = `rgba(255, 255, 255, ${drops[i].opacity})`;
        ctx.moveTo(drops[i].x + drops[i].length * Math.cos(drops[i].deg), drops[i].y - drops[i].length * Math.sin(drops[i].deg));
        ctx.lineTo(drops[i].x, drops[i].y);
        ctx.stroke();

        drops[i].x = drops[i].x + (v * (1000 / fps) * Math.cos(drops[i].deg))
        drops[i].y = drops[i].y - v * (1000 / fps) * Math.sin(drops[i].deg)

        if(drops[i].x < drops[i].length * Math.cos(drops[i].deg) || drops[i].y > - v * (1000 / fps) * Math.sin(drops[i].deg) + window.innerHeight) {
          drops[i].x = Math.random() * (window.innerWidth + 75);
          drops[i].y = -75;
          drops[i].length = 50 + 100 * Math.random();
          drops[i].deg = - Math.PI / 18 * (9.5 + Math.random());
          drops[i].opacity = 0.2 + 0.6 * Math.random();
        }

      }

      let actTime = new Date().getTime();
      if (actTime - lastFlashTime > 6000) {
        if (Math.random() > 0.75) {
          makeFlash(200, 500);
          lastFlashTime = actTime;
          // console.log('flash')
        }
        else
        {
          // console.log('no flash')
          lastFlashTime += 500;
        }
      }
    }, 1000 / fps)

  }
  drawDrops(400);
}
